wymusic 0.8.4
================
Embed Netease(163) cloud music audio tracks

<p align="center"><img src="wymusic-screenshot.png?raw=true" width="389" height="536" alt="Screenshot"></p>

Due to copyright factors, NetEase Cloud Music officially only provides services to mainland China, so the English version of the description file will not be repeated.

This extension is modified based on [Soundcloud extension](https://github.com/datenstrom/yellow-extensions/), thanks to the original author's code contribution.

<p>
<a href="README.md">Chinese README</a>
</p>
